# Trading Alarm Backend (Render-ready)

**Features**
- Store up to 10 alerts per device token (enforced in API)
- 3-second polling loop for Binance symbols (free, no key needed)
- TradingView **webhook** endpoint for true TradingView prices (no polling)
- Expo Push notifications
- SQLite persistence
- Flask API + a separate worker (Render Background Worker)

## Quick Deploy on Render

1) Create a new **Web Service** from this repo (or zip upload), set:
   - Runtime: Python 3.11
   - Start command: `gunicorn server:app`
   - Environment: add `EXPO_DEBUG=false` (optional)

2) Create a **Background Worker** on Render from the same repo with:
   - Start command: `python worker.py`

3) Grab the Web Service URL, e.g. `https://YOUR-SERVICE.onrender.com`.

4) In the Expo app, set `BACKEND_URL` to that URL in `app/config.ts` (already points to `http://localhost:5000` by default).

5) **TradingView Alerts (true TV prices):**
   - In a TradingView chart, make an alert and set **Webhook URL** to:
     `https://YOUR-SERVICE.onrender.com/tv_webhook?secret=YOUR_SECRET`
   - Use this alert message template:
     ```
     {"symbol":"{{ticker}}","price":{{close}}}
     ```
   - Then, in the Expo app, create an alert with **Source = TradingView** for the same symbol and threshold.
   - The backend evaluates your TV-sourced alerts whenever a webhook arrives (no 3s polling needed).

## Local Dev

```bash
pip install -r requirements.txt
# Start API
flask --app server run --host 0.0.0.0 --port 5000
# Start worker (separate terminal)
python worker.py
```

## API

- `POST /register_alert` JSON:
  `{ "token": "<expoPushToken>", "symbol": "BTCUSDT", "direction":"Above|Below", "price": 65000, "source": "binance|tradingview" }`
  Limits: max 10 active alerts per token.

- `GET /alerts?token=...` → list your alerts
- `DELETE /alert/<id>?token=...` → delete your alert
- `POST /tv_webhook?secret=YOUR_SECRET` → body: `{ "symbol": "BTCUSDT", "price": 65123.45 }`

## Notes
- 3-second loops are only for **binance** source alerts. TradingView alerts are event-driven via webhook.
- Render free tier may sleep; background worker usually stays up but can restart — SQLite is persisted.
- Symbols for Binance must match Binance format (e.g., BTCUSDT, ETHUSDT).
