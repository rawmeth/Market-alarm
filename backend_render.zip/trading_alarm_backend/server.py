import os
import time
import json
import secrets
from flask import Flask, request, jsonify
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, select, func
from sqlalchemy.orm import sessionmaker, declarative_base
import requests
from datetime import datetime

DB_URL = os.environ.get("DATABASE_URL", "sqlite:///alerts.db")
TV_SECRET = os.environ.get("TV_SECRET", "changeme")  # set on Render

engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if DB_URL.startswith("sqlite") else {})
Session = sessionmaker(bind=engine)
Base = declarative_base()

class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    token = Column(String, index=True, nullable=False)  # Expo push token
    symbol = Column(String, index=True, nullable=False)
    direction = Column(String, nullable=False)  # 'Above' or 'Below'
    price = Column(Float, nullable=False)
    source = Column(String, nullable=False, default="binance")  # 'binance' or 'tradingview'
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(engine)

app = Flask(__name__)

def count_active_alerts(session, token):
    return session.query(func.count(Alert.id)).filter(Alert.token == token, Alert.active == True).scalar()

@app.route("/register_alert", methods=["POST"])
def register_alert():
    data = request.get_json(force=True)
    token = data.get("token")
    symbol = data.get("symbol", "").upper().strip()
    direction = data.get("direction", "Above")
    price = float(data.get("price"))
    source = data.get("source", "binance")
    if not token or not symbol or direction not in ("Above", "Below"):
        return jsonify({"error": "Invalid payload"}), 400
    with Session() as s:
        if count_active_alerts(s, token) >= 10:
            return jsonify({"error": "Max 10 active alerts per device token"}), 400
        alert = Alert(token=token, symbol=symbol, direction=direction, price=price, source=source, active=True)
        s.add(alert)
        s.commit()
        return jsonify({"status": "ok", "id": alert.id})

@app.route("/alerts", methods=["GET"])
def list_alerts():
    token = request.args.get("token", "")
    with Session() as s:
        rows = s.query(Alert).filter(Alert.token == token, Alert.active == True).order_by(Alert.created_at.desc()).all()
        return jsonify([{"id": r.id, "symbol": r.symbol, "direction": r.direction, "price": r.price, "source": r.source} for r in rows])

@app.route("/alert/<int:alert_id>", methods=["DELETE"])
def delete_alert(alert_id):
    token = request.args.get("token", "")
    with Session() as s:
        row = s.query(Alert).filter(Alert.id == alert_id, Alert.token == token).first()
        if not row:
            return jsonify({"error": "Not found"}), 404
        row.active = False
        s.commit()
        return jsonify({"status": "deleted"})

# TradingView webhook endpoint for *true TV price* events
@app.route("/tv_webhook", methods=["POST"])
def tv_webhook():
    secret = request.args.get("secret", "")
    if secret != TV_SECRET:
        return jsonify({"error": "Unauthorized"}), 401
    data = request.get_json(force=True)
    symbol = str(data.get("symbol", "")).upper()
    try:
        price = float(data.get("price"))
    except Exception:
        return jsonify({"error": "Invalid price"}), 400
    # Evaluate TradingView-sourced alerts immediately
    triggered = _evaluate_symbol_price(symbol, price, source="tradingview")
    return jsonify({"status": "ok", "triggered": triggered})

def _expo_push(token, title, body):
    # Expo push API
    r = requests.post("https://exp.host/--/api/v2/push/send", json={"to": token, "title": title, "body": body})
    return r.status_code

def _evaluate_symbol_price(symbol, price, source="binance"):
    # Returns # of triggered alerts
    count = 0
    with Session() as s:
        q = s.query(Alert).filter(Alert.active == True, Alert.symbol == symbol, Alert.source == source).all()
        for a in q:
            if (a.direction == "Above" and price >= a.price) or (a.direction == "Below" and price <= a.price):
                _expo_push(a.token, f"{symbol} Alert!", f"Price {price} crossed {a.price}")
                a.active = False
                s.add(a)
                count += 1
        s.commit()
    return count

# Optional health check
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"})

# This route is only used by the worker internally if you want to ping it
@app.route("/_internal_eval", methods=["POST"])
def internal_eval():
    payload = request.get_json(force=True)
    symbol = payload["symbol"]
    price = float(payload["price"])
    source = payload.get("source", "binance")
    n = _evaluate_symbol_price(symbol, price, source=source)
    return jsonify({"triggered": n})
