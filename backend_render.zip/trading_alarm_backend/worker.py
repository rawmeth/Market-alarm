import os
import time
import requests
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy import Column, Integer, String, Float, Boolean, DateTime, func
from datetime import datetime

DB_URL = os.environ.get("DATABASE_URL", "sqlite:///alerts.db")
engine = create_engine(DB_URL, connect_args={"check_same_thread": False} if DB_URL.startswith("sqlite") else {})
Session = sessionmaker(bind=engine)
Base = declarative_base()

class Alert(Base):
    __tablename__ = "alerts"
    id = Column(Integer, primary_key=True)
    token = Column(String, index=True, nullable=False)
    symbol = Column(String, index=True, nullable=False)
    direction = Column(String, nullable=False)
    price = Column(Float, nullable=False)
    source = Column(String, nullable=False, default="binance")
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

Base.metadata.create_all(engine)

API_BASE = "https://api.binance.com"

def get_symbols_to_check():
    with Session() as s:
        rows = s.query(Alert.symbol).filter(Alert.active == True, Alert.source == "binance").distinct().all()
        return [r[0] for r in rows]

def fetch_price(symbol):
    url = f"{API_BASE}/api/v3/ticker/price?symbol={symbol}"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    return float(r.json()["price"])

def eval_symbol(server_url, symbol, price):
    r = requests.post(server_url + "/_internal_eval", json={"symbol": symbol, "price": price, "source": "binance"}, timeout=10)
    r.raise_for_status()

def main():
    server_url = os.environ.get("SERVER_URL", "http://localhost:5000")
    print("[worker] started; polling every 3s")
    while True:
        try:
            symbols = get_symbols_to_check()
            for sym in symbols:
                try:
                    p = fetch_price(sym)
                    eval_symbol(server_url, sym, p)
                except Exception as e:
                    print("[worker] error for", sym, e)
        except Exception as e:
            print("[worker] loop error:", e)
        time.sleep(3)  # 3-second gap

if __name__ == "__main__":
    main()
